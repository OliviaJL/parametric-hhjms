
# This function returns the log likelihood function of 
# the Cox model that shares some parameters with 
# the mixed effect models.

cox_loglike <- function(survObject, survPar=NULL){
   model <- survObject$fm
   status <- survObject$event
   resp <- fmReverse(model)$resp  # response variable (event time)
   rvX <- fmReverse(model)$rvX  # baseline covariates
   if(sum(toupper(rvX)=='NULL')>0 | sum(rvX=='1')>0){ 
    linear1 <- "0"
    par=c()
   }else{
     p <- length(rvX)   # dimension of fixed parameters
     par <- paste(survObject$par, 1:p-1, sep="")  # name fixed parameters
     linear1 <- paste(par,"*", rvX, collapse="+", sep="")
   }
   linear_pred <- linear1
  # log likelihood                
  if(is.null(survObject$distribution)){
    loglike <- paste(status,"*( log(h0) +", linear_pred, ") - 
                   exp(", linear_pred, ")*Th0", sep="")
    str_val <- survObject$str_val
    names(str_val) <- par
  } else if(survObject$distribution=="weibull"){

    # log-likelihood for weibull model
    loglike <- paste(status,"*( Wlogscale+log(Wshape)+log(",resp,")*(Wshape-1) +", linear_pred, ") - 
                   exp(Wlogscale+", linear_pred, ")*",resp,"^Wshape", sep="")
    if(is.null(survPar)){ survPar=c(0,1) }
    str_val <- c(survObject$str_val, survPar)
    par=c(par,"Wlogscale", "Wshape")
    names(str_val) <- par
  } else if (survObject$distribution=="loglogistic") {
    
    ## log-likelihood for log-logistic AFT model
    
    #logf <- paste('-(log(',resp, ')-LLmu-',linear_pred,')/LLsigma-2*log(1+exp(-(log(',resp,')-LLmu-',linear_pred,')/LLsigma))')
    #logS <- paste('-log(1+exp((log(',resp, ')-LLmu-',linear_pred,')/LLsigma))')
    #loglike <- paste('-',status,'*(log(LLsigma*',resp,'+',status,'*(', logf, ')+(1-', status,')*(', logS, ')))')
    #if(is.null(survPar)){ survPar = c(0,3) }
    #str_val <- c(survObject$str_val, survPar)
    #par = c(par, 'LLmu', "LLsigma")
    #names(str_val) <- par
    
    logf <- paste('-(log(',resp, ')-',linear_pred,')/sigma-2*log(1+exp(-(log(',resp,')-',linear_pred,')/sigma))', sep='')
    logS <- paste('-log(1+exp((log(',resp, ')-',linear_pred,')/sigma))', sep='')
    loglike <- paste(status,'*(-log(sigma)', logf, ')+(1-', status,')*(', logS, ')', sep='')
    if(is.null(survPar)){ survPar = 1 }
    str_val <- c(survObject$str_val, survPar)
    par = c(par, "sigma")
    names(str_val) <- par
    
    #loglike <- paste(status,"*(log(LLshape) + LLshape*(LLscale-LLshape*log(",linear_pred,')) + (LLshape-1)*log(',resp,') - 
    #                 log(1 + exp(LLscale - LLshape*log(',linear_pred,'))*', resp,'^LLshape))')  
    #if(is.null(survPar)){ survPar = c(0,1) }
    #str_val <- c(survObject$str_val, survPar)
    #par = c(par, 'LLscale', "LLshape")
    #names(str_val) <- par
  }
  
  return(list(resp=resp, loglike=loglike, par=par, linear_pred=linear_pred, str_val=str_val))
}

